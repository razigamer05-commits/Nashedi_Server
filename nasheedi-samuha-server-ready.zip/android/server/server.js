import http from 'node:http';
import { WebSocketServer } from 'ws';
import { randomBytes, randomInt } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const PORT=process.env.PORT||3000;
const rooms=new Map();
const locations=[
 ['Beach','Sand, waves and summer'],['Cinema','A place with a big screen'],['Airport','People arrive and depart here'],['School','Students spend much of the day here'],['Restaurant','People come here to eat'],['Hospital','Doctors and patients are here'],['Football Stadium','A place where a major match can happen'],['Supermarket','You push a cart here'],['Train Station','A place where trains stop'],['Amusement Park','Rides, games and lots of noise']
];
const roomId=()=>String(randomInt(100,1000));
const playerId=()=>randomBytes(5).toString('hex');
const send=(ws,m)=>ws.readyState===1&&ws.send(JSON.stringify(m));
const broadcast=(room,m)=>room.players.forEach(p=>send(p.ws,m));
function safeName(x){return String(x||'Player').slice(0,16)}
function state(room){return {type:'state',room:room.code,game:room.game,phase:room.phase,players:room.players.map(p=>({id:p.id,name:p.name,ready:p.ready,color:p.color})),host:room.players[0]?.id,turn:room.ludo?.turn??null,dice:room.ludo?.dice??null};}
function resetLobby(room){room.game='menu';room.phase='lobby';room.spy=null;room.votes={};room.ludo=null;room.uno=null;room.players.forEach(p=>p.ready=false)}
function startSpy(room){
 if(room.players.length<2)return;
 const loc=locations[randomInt(locations.length)];
 const spyIndexes=new Set();
 // Spy mode always has exactly one spy. The server sends the secret location only to citizens.
 spyIndexes.add(randomInt(room.players.length));
 room.game='spy';room.phase='roles';room.spy={place:loc[0],clue:loc[1],spies:[...spyIndexes].map(i=>room.players[i].id)};room.votes={};
 room.players.forEach((p,i)=>send(p.ws,{type:'spy-role',role:spyIndexes.has(i)?'spy':'citizen',place:spyIndexes.has(i)?null:loc[0],clue:spyIndexes.has(i)?null:loc[1]}));
 broadcast(room,state(room));
}
// Classic 4-player Ludo data: 52-track + 6 home-path cells per player. Server owns all dice/moves.
const START=[0,13,26,39];
const COLORS=['red','green','yellow','blue'];
const colorNames=['Red','Green','Yellow','Blue'];
const SAFE=[0,8,13,21,26,34,39,47];
function newLudo(){return {turn:0,dice:null,winner:null,tokens:Array.from({length:4},()=>Array(4).fill(-1)),finished:[0,0,0,0],sixStreak:0};}
function globalPos(player,step){return (START[player]+step)%52}
function canMove(l,pi,tok,roll){const s=l.tokens[pi][tok];if(s===57)return false;if(s===-1)return roll===6;return s+roll<=57}
function movable(l,pi,roll){return l.tokens[pi].map((_,t)=>canMove(l,pi,t,roll)?t:null).filter(x=>x!==null)}
function startLudo(room){if(room.players.length!==4)return;room.game='ludo';room.phase='playing';room.ludo=newLudo();room.players.forEach(p=>p.ready=false);broadcast(room,{type:'ludo-start',state:publicLudo(room),message:'Red goes first'});}
function publicLudo(room){return {tokens:room.ludo.tokens,turn:room.ludo.turn,dice:room.ludo.dice,winner:room.ludo.winner,finished:room.ludo.finished,sixStreak:room.ludo.sixStreak};}
function nextTurn(room,extra=false){room.ludo.turn=extra?room.ludo.turn:(room.ludo.turn+1)%room.players.length;room.ludo.dice=null}
function ludoRoll(room,me){const pi=room.players.findIndex(p=>p.id===me.id);const l=room.ludo;if(pi!==l.turn||l.dice!==null||l.winner!==null)return;l.dice=randomInt(1,7);const roll=l.dice;
 if(roll===6){l.sixStreak++;if(l.sixStreak===3){l.sixStreak=0;l.dice=null;nextTurn(room,false);broadcast(room,{type:'ludo-state',state:publicLudo(room),message:`${colorNames[pi]} rolled three 6s in a row — turn forfeited.`});return}}else l.sixStreak=0;
 const moves=movable(room,pi,roll);if(!moves.length){const extra=roll===6;nextTurn(room,extra);broadcast(room,{type:'ludo-state',state:publicLudo(room),message:extra?`${colorNames[pi]} rolled ${roll}. No legal move — roll again.`:`${colorNames[pi]} rolled ${roll}. No legal move — next turn.`});return}broadcast(room,{type:'ludo-state',state:publicLudo(room),movable:moves});}
function ludoMove(room,me,tok){const pi=room.players.findIndex(p=>p.id===me.id);const l=room.ludo;if(pi!==l.turn||l.dice===null)return;tok=Number(tok);if(!Number.isInteger(tok)||tok<0||tok>3||!canMove(l,pi,tok,l.dice))return;
 const roll=l.dice;let s=l.tokens[pi][tok];if(s===-1)s=0;else s+=roll;l.tokens[pi][tok]=s;
 if(s===57){l.finished[pi]++;if(l.finished[pi]===4){l.winner=pi;broadcast(room,{type:'ludo-state',state:publicLudo(room),message:`${me.name} wins!`});return}}
 let extra=roll===6;
 // Capture on the shared 52-cell track, excluding the four safe start squares.
 if(s>=0&&s<52){const gp=globalPos(pi,s);const safe=SAFE.includes(gp);if(!safe){for(let op=0;op<room.players.length;op++){if(op===pi)continue;for(let ot=0;ot<4;ot++){const os=l.tokens[op][ot];if(os>=0&&os<52&&globalPos(op,os)===gp){l.tokens[op][ot]=-1;}}}}}
 nextTurn(room,extra);broadcast(room,{type:'ludo-state',state:publicLudo(room),message:extra?'Six! Roll again.':'Move complete.'});
}

// UNO-style multiplayer: server owns deck, hands, turn order and card legality.
const UNO_COLORS=['red','yellow','green','blue'];
const UNO_TYPES=['0','1','2','3','4','5','6','7','8','9','skip','reverse','draw2'];
function unoCard(color,type){return {id:randomBytes(5).toString('hex'),color,type};}
function buildUnoDeck(){
 const d=[];
 for(const c of UNO_COLORS){d.push(unoCard(c,'0'));for(let n=1;n<=9;n++){d.push(unoCard(c,String(n)),unoCard(c,String(n)));}for(const t of ['skip','reverse','draw2']){d.push(unoCard(c,t),unoCard(c,t));}}
 for(let i=0;i<4;i++){d.push(unoCard('wild','wild'),unoCard('wild','draw4'));}
 return d;
}
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=randomInt(i+1);[a[i],a[j]]=[a[j],a[i]];}return a}
function unoPublic(room){const u=room.uno;return {hands:u.hands.map(h=>h.length),hand:u.hands[room.players.findIndex(p=>p.id===room._viewerId)]||[],top:u.discard.at(-1),turn:u.turn,color:u.color,winner:u.winner,pendingUno:u.pendingUno};}
function unoStateFor(room,p){room._viewerId=p.id;const out=unoPublic(room);delete room._viewerId;return out;}
function broadcastUno(room,message){for(const p of room.players)send(p.ws,{type:'uno-state',state:unoStateFor(room,p),message:message||''});}
function unoPlayable(card,top,color){if(card.color==='wild')return true;if(card.color===color)return true;if(card.type===top.type&&top.color!=='wild')return true;return false}
function refillUno(room){const u=room.uno;if(u.deck.length)return;const top=u.discard.pop();const rest=u.discard.splice(0);shuffle(rest);u.deck=rest;u.discard=[top]}
function drawUno(room,count=1){const cards=[];for(let i=0;i<count;i++){if(!room.uno.deck.length)refillUno(room);if(room.uno.deck.length)cards.push(room.uno.deck.pop());}return cards}
function startUno(room){if(room.players.length<2)return;const deck=shuffle(buildUnoDeck());const hands=room.players.map(()=>[]);for(let i=0;i<7;i++)for(let p=0;p<hands.length;p++)hands[p].push(deck.pop());let top=deck.pop();while(top.color==='wild'){deck.unshift(top);top=deck.pop();}room.game='uno';room.phase='playing';room.uno={deck,discard:[top],hands,turn:0,color:top.color,winner:null,pendingUno:null,direction:1};
 // If the opening card is an action, apply its normal effect to the first player/turn.
 if(top.type==='reverse'&&room.players.length===2)room.uno.turn=1; else if(top.type==='skip')room.uno.turn=1; else if(top.type==='draw2'){room.uno.hands[0].push(...drawUno(room,2));room.uno.turn=1;}
 broadcastUno(room,'UNO started!');}
function unoPlay(room,me,cardId,chosenColor){const pi=room.players.findIndex(p=>p.id===me.id),u=room.uno;if(pi!==u.turn||u.winner!==null)return;if(u.pendingUno&&u.pendingUno!==me.id){const pending=room.players.findIndex(p=>p.id===u.pendingUno);if(pending>=0)u.hands[pending].push(...drawUno(room,2));u.pendingUno=null;}const hand=u.hands[pi];const idx=hand.findIndex(c=>c.id===cardId);if(idx<0)return;const card=hand[idx];const top=u.discard.at(-1);if(!unoPlayable(card,top,u.color))return send(me.ws,{type:'error',message:'That card cannot be played now.'});if(card.type==='draw4'&&u.hands[pi].some(c=>c.color!=='wild'&&c.color===u.color))return send(me.ws,{type:'error',message:'Wild +4 can only be played when you have no card matching the current color.'});hand.splice(idx,1);u.discard.push(card);if(hand.length===1)u.pendingUno=me.id;else u.pendingUno=null;if(hand.length===0){u.winner=pi;u.pendingUno=null;broadcastUno(room,`${me.name} wins UNO!`);return}
 const step=()=> (u.turn+u.direction+room.players.length)%room.players.length;let next=step();u.color=card.color==='wild'?(UNO_COLORS.includes(chosenColor)?chosenColor:UNO_COLORS[randomInt(UNO_COLORS.length)]):card.color;let skip=false,draw=0;
 if(card.type==='skip')skip=true;if(card.type==='reverse'){if(room.players.length>2){u.direction*=-1;next=(pi+u.direction+room.players.length)%room.players.length;}else skip=true;}if(card.type==='draw2')draw=2;if(card.type==='draw4')draw=4;if(skip)next=(next+u.direction+room.players.length)%room.players.length;u.turn=next;if(draw){u.hands[next].push(...drawUno(room,draw));u.turn=(next+u.direction+room.players.length)%room.players.length;}broadcastUno(room,`${me.name} played ${card.type==='draw4'?'Wild +4':card.type==='wild'?'Wild':card.type}.`);}
function unoDraw(room,me){const pi=room.players.findIndex(p=>p.id===me.id),u=room.uno;if(pi!==u.turn||u.winner!==null)return;if(u.pendingUno){const pending=room.players.findIndex(p=>p.id===u.pendingUno);if(pending>=0)u.hands[pending].push(...drawUno(room,2));u.pendingUno=null;}const card=drawUno(room,1)[0];if(card)u.hands[pi].push(card);const top=u.discard.at(-1);if(card&&unoPlayable(card,top,u.color))broadcastUno(room,`${me.name} drew a playable card.`);else{u.turn=(pi+u.direction+room.players.length)%room.players.length;broadcastUno(room,`${me.name} drew a card. Turn passed.`);}}
function unoCall(room,me){const pi=room.players.findIndex(p=>p.id===me.id),u=room.uno;if(u.hands[pi]?.length!==1)return send(me.ws,{type:'error',message:'You can call UNO only with one card left.'});if(u.pendingUno===me.id){u.pendingUno=null;broadcastUno(room,`${me.name} called UNO!`);}}
function createRoom(ws,msg){let code=roomId();while(rooms.has(code))code=roomId();const room={code,game:'menu',phase:'lobby',players:[],spy:null,spyCount:1,votes:{},ludo:null,uno:null};rooms.set(code,room);joinRoom(room,ws,msg)}
function joinRoom(room,ws,msg){if(room.players.length>=4||room.phase!=='lobby')return send(ws,{type:'error',message:'Room is full or already playing.'});const p={id:playerId(),name:safeName(msg.name),ws,ready:false,color:COLORS[room.players.length]};room.players.push(p);ws.room=room;ws.pid=p.id;send(ws,{type:'joined',code:room.code,playerId:p.id});broadcast(room,state(room));}
function vote(room,me,target){if(room.phase!=='voting')return;const t=room.players.find(p=>p.id===target);if(!t||t.id===me.id)return;room.votes[me.id]=t.id;broadcast(room,{type:'vote-count',count:Object.keys(room.votes).length,total:room.players.length});if(Object.keys(room.votes).length===room.players.length){const counts={};Object.values(room.votes).forEach(x=>counts[x]=(counts[x]||0)+1);const accused=Object.entries(counts).sort((a,b)=>b[1]-a[1])[0]?.[0];const caught=room.spy.spies.includes(accused);room.phase='result';broadcast(room,{type:'spy-result',caught,spyNames:room.players.filter(p=>room.spy.spies.includes(p.id)).map(p=>p.name),place:room.spy.place});}}
function handle(ws,m){if(!m||typeof m.type!=='string')return;
 if(m.type==='create')return createRoom(ws,m);
 if(m.type==='join'){const code=String(m.code||'').trim();if(!/^\d{3}$/.test(code))return send(ws,{type:'error',message:'Enter a valid 3-digit room code.'});const room=rooms.get(code);if(!room)return send(ws,{type:'error',message:'Room not found.'});return joinRoom(room,ws,m)}
 const room=ws.room;if(!room)return send(ws,{type:'error',message:'Join a room first.'});const me=room.players.find(p=>p.id===ws.pid);if(!me)return;
 if(m.type==='set-spy-count'&&room.game==='menu'){room.spyCount=1;broadcast(room,state(room));return}
 if(m.type==='ready'&&room.game==='menu'){me.ready=!me.ready;broadcast(room,state(room));return}
 if(m.type==='start-spy'&&room.game==='menu'&&room.players[0].id===me.id){startSpy(room);return}
 if(m.type==='start-ludo'&&room.game==='menu'&&room.players[0].id===me.id){if(room.players.length!==4)return send(me.ws,{type:'error',message:'Ludo needs exactly 4 players.'});startLudo(room);return}
 if(m.type==='start-uno'&&room.game==='menu'&&room.players[0].id===me.id){if(room.players.length<2)return send(me.ws,{type:'error',message:'UNO needs at least 2 players.'});startUno(room);return}
 if(m.type==='uno-play'&&room.game==='uno')return unoPlay(room,me,m.cardId,m.color);
 if(m.type==='uno-draw'&&room.game==='uno')return unoDraw(room,me);
 if(m.type==='uno-call'&&room.game==='uno')return unoCall(room,me);
 if(m.type==='start-voting'&&room.game==='spy'&&room.phase==='roles'){room.phase='voting';broadcast(room,{type:'phase',phase:'voting'});return}
 if(m.type==='vote'&&room.game==='spy')return vote(room,me,m.target);
 if(m.type==='ludo-roll'&&room.game==='ludo')return ludoRoll(room,me);
 if(m.type==='ludo-move'&&room.game==='ludo')return ludoMove(room,me,m.token);
 if(m.type==='back-menu'&&room.players[0].id===me.id){resetLobby(room);broadcast(room,state(room));}
}
const server=http.createServer((req,res)=>{let p=new URL(req.url,`http://${req.headers.host}`).pathname;if(p==='/')p='/index.html';const root=path.join(process.cwd(),'public');const file=path.resolve(root,'.'+p);if(!file.startsWith(root))return res.writeHead(403).end();fs.readFile(file,(e,d)=>{if(e)return res.writeHead(404).end('Not found');const ext=path.extname(file);const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.webmanifest':'application/manifest+json','.json':'application/json'};res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':'no-store'});res.end(d)});});
const wss=new WebSocketServer({server});wss.on('connection',ws=>{ws.on('message',raw=>{try{handle(ws,JSON.parse(raw))}catch(e){send(ws,{type:'error',message:'Request failed.'})}});ws.on('close',()=>{const r=ws.room;if(!r)return;r.players=r.players.filter(p=>p.ws!==ws);if(!r.players.length)rooms.delete(r.code);else{r.players[0].ready=false;if((r.game==='ludo'||r.game==='uno')&&r.phase==='playing'){r.game='menu';r.phase='lobby';r.ludo=null;r.uno=null}broadcast(r,state(r));}})});
server.listen(PORT,()=>console.log(`Mini Party Online V2 on ${PORT}`));
