# Nasheedi Samuha — Server Deployment

## Render
1. Put this `server` folder in a GitHub repository.
2. In Render, create a **Web Service** from that repository.
3. Set the root directory to `android/server` if the repository contains the full Android project.
4. Build command: `npm install`
5. Start command: `npm start`
6. After deployment, Render gives you an HTTPS URL such as `https://your-name.onrender.com`.

The browser client automatically uses `wss://` when opened over HTTPS.

## Android app
Replace the placeholder URL in:
`android/app/src/main/java/com/nasheedi/samuha/MainActivity.java`

with the deployed HTTPS URL. Example:
`https://your-name.onrender.com`

Also update `android/app/src/main/res/values/strings.xml` if desired.

Do not commit passwords, API keys, or private credentials.
