# Nasheedi Samuha — Android Studio project

This is the Android wrapper for the Nasheedi Samuha multiplayer web game.

## Before building
1. Deploy the Node.js/WebSocket server from the `server` folder/project to an HTTPS host.
2. Replace `SERVER_URL` in `app/src/main/java/com/nasheedi/samuha/MainActivity.java` with that HTTPS URL.
3. Open this folder in Android Studio.
4. Let Android Studio download the Android Gradle Plugin/dependencies.
5. Build > Build APK(s).

The app uses a WebView so Spy, Ludo and UNO stay synchronized with the same online game server.

## Room system
- Create Room generates a unique active **3-digit** room code (100–999).
- Share Link uses `?room=123`, so opening the link pre-fills the join code.
- Join Room accepts exactly 3 digits.
- Maximum 4 players remains enforced by the server.
