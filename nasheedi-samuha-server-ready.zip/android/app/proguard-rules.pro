# Nasheedi Samuha: no custom shrinking rules required.
